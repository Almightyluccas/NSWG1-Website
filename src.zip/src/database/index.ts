import { DatabaseClient } from './DatabaseClient'

export const database: DatabaseClient = DatabaseClient.getInstance()