import { PerscomClient } from './PerscomClient'

export const perscom = new PerscomClient()